using System;

public class Program      //DO NOT change the class name
{
    //implement code here
    public static void Main(string[] args){
        string rev="";
        Console.WriteLine("Enter a string");
        string text=Console.ReadLine();
        string[] words=text.Split(" ");
        for(int i=words.Length-1;i>=0;i--){
            rev+=words[i]+" ";
        }
        Console.WriteLine(rev);
    }
}
