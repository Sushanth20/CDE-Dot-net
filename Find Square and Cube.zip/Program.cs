using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Methods2               //DO NOT Change namespace name
{
    public class Program                //DO NOT Change class 'Program' name
    {
        public static void Main(string[] args)        //DO NOT Change 'Main' method Signature
        {
            //Implement your code here
            Console.WriteLine("Enter a Number");
            string n=Console.ReadLine();
            double num=Convert.ToDouble(n);
            double square=FindSquare(num);
            double cube=FindCube(num);
            Console.WriteLine("Square of "+num+" is {0}",square);
            Console.WriteLine("Cube of "+num+" is {0}",cube);
        }

      //Implement methods here. Keep the method 'public' and 'static'
      public static double FindSquare(double num){
          double sres=num*num;
          return sres;
      }
      public static double FindCube(double num){
          double cres=num*num*num;
          return cres;
      }
    }
}
