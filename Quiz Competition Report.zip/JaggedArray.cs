using System;


namespace JaggedArray      //DO NOT Change the namespace name
{
    public class Program    //DO NOT Change the class name
    {
        public static void Main(string[] args)    //DO NOT change the method signature
        {
	        //Implement code here
	        // Get input from the user and construct a jagged array 
	        Console.WriteLine("Enter the number of teams:");
	        int n=int.Parse(Console.ReadLine());
	        int[][] teams=new int[n][];
	        for(int i=0;i<n;i++){
	            Console.WriteLine("No.of attempts for team {0}",(i+1));
	            int attempts=int.Parse(Console.ReadLine());
	            teams[i]=new int[attempts];
	        }
	        for(int i=0;i<n;i++){
	            Console.WriteLine("Enter the score for team {0}",(i+1));
	            for(int j=0;j<teams[i].Length;j++)
	                teams[i][j]=int.Parse(Console.ReadLine());
	        }
	        Console.WriteLine(GetTotalScore(teams));
        }
        
        public static String GetTotalScore(int[][] array)        //DO NOT change the method signature
        {
            //Implement code here 
            //Method to calculate total score for each team and return a string as specified in the sample output.
            string res="";
            for(int i=0;i<array.Length;i++){
                
                int sum=0;
                for(int j=0;j<array[i].Length;j++){
                   sum+=array[i][j];
                }
                res+="Team "+(i+1)+" Total Score is "+sum+" .";
                
            }
            return res;
            
        }

    }
}
