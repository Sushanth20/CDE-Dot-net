using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgFundamentals2  //DO NOT change the namespace name
{
    public class Program      //DO NOT change the class name
    {
        public static void Main(string[] args)     //DO NOT change the 'Main' method signature
        {
            //Implement the code here
            int pizza,puff,pepsi;
            Console.WriteLine("Enter the number of pizzas bought : ");
            pizza=int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the number of puffs bought : ");
            puff=int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the number of pepsi bought : ");
            pepsi=int.Parse(Console.ReadLine());
            int pizza_p=200,puff_p=40,pepsi_p=120;
            int pizza_t=pizza*pizza_p;
            int puff_t=puff*puff_p;
            int pepsi_t=pepsi*pepsi_p;
            Console.WriteLine("Bill Details");
            Console.WriteLine("Cost of Pizzas :"+pizza_t);
            Console.WriteLine("Cost of Puffs :"+puff_t);
            Console.WriteLine("Cost of Pepsis :"+pepsi_t);
            int total=pizza_t+puff_t+pepsi_t;
            double gst=total*0.12;
            double cess=total*0.05;
            Console.WriteLine("GST 12% : "+gst);
            Console.WriteLine("CESS 5% : "+cess);
            Console.WriteLine("Total Price :"+total);
        }
    }
}
