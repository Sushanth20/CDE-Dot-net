using System;
using System.Collections;
using System.Globalization;
using System.IO;


    public class Program  //DO NOT CHANGE the name of class 'Program'
    {
        public static void Main(string[] args) //DO NOT CHANGE 'Main' Signature
        {
            
            //Fill the code here
            StreamReader readData=new StreamReader("input.csv");
            string data="";
            Product p;
            ArrayList filedata=new ArrayList();
            while((data=readData.ReadLine())!=null){
                string[] i=data.Split(',');
                string productName=i[0].Trim();
                string serialNumber=i[1].Trim();
                DateTime purchaseDate=DateTime.ParseExact(i[2].Trim(),"dd-mm-yyyy",null);
                double purchaseCost=double.Parse(i[3].Trim());
                p=new Product(productName,serialNumber,purchaseDate,purchaseCost);
                filedata.Add(p);
            }
            Console.WriteLine("{0}",String.Format("{0,-15}{1,-15}{2,-15}{3,-15}", "Product Name", "Serial Number", "Purchase Date", "Purchase Cost"));
            foreach(var obj in filedata)
            {
                Product product=(Product)obj;
                Console.WriteLine("{0}",product.ToString());
            }
        }


    }

   

