select rental_id, car_id, customer_id , km_driven from rentals
where extract(month from pickup_date)=8 and extract(year from pickup_date)=2019 order by rental_id;
