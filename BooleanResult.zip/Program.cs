using System;

public class Program      //DO NOT change the class name
{
    //implement code here
    public static void Main(string[] args){
    int x,y;
    bool res;
    Console.WriteLine("Enter the value for x");
    x=int.Parse(Console.ReadLine());
    Console.WriteLine("Enter the value for y");
    y=int.Parse(Console.ReadLine());
    if(x < y){
        res=true;
    }else{
        res=false;
    }
    Console.WriteLine("x is less than y is "+res);
    }
}
